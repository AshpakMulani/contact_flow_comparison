const { config } = require('process');


function deepDiff(oldObj, newObj) {
    const diff = {};
  
    function compareObjects(obj1, obj2, path = []) {
      for (const key in obj2) {
        const newPath = [...path, key];
        if (obj1){
        if (!(key in obj1)) {
          diff[newPath.join('.')] = { newValue: obj2[key] };
        } else if (typeof obj2[key] === 'object' && obj2[key] !== null) {
          if (typeof obj1[key] === 'object' && obj1[key] !== null) {
            compareObjects(obj1[key], obj2[key], newPath);
          } else {
            diff[newPath.join('.')] = { newValue: obj2[key], oldValue: obj1[key] };
          }
        } else if (obj1[key] !== obj2[key]) {
          diff[newPath.join('.')] = { newValue: obj2[key], oldValue: obj1[key] };
        }
      }
    }
      
      

      /// find deleted attributes
      
      for (const key in obj1) {
        const newPath = [...path, key];
        
        if (obj2){
        if (!(key in obj2)) {
          diff[newPath.join('.')] = { oldValue: obj1[key] };
        } 
        }
      }
      
    }
    
       
    compareObjects(oldObj, newObj);
  
    return diff;
  }




  function readFile(filePath){

    const fs = require('fs')
 
    data = fs.readFileSync(filePath, (err, data) => {
    if (err) throw err; 
    return data ;
       
    })
 
    return data
}

function getidentifires(jsonobject){
    var identifires = []


    if (! (jsonobject)){
        throw "Invalid input contact flow bject";
    }

    for(var key in jsonobject){
        identifires.push(jsonobject[key].Identifier)
    }

    return identifires;

}

function findObjectWithValue(obj, item, value) {   
    function objFind(obj, item, value){
        for(var key in obj) {                                 

           if(obj[key] && obj[key].length ==undefined) {     
                if(obj[item]==value){
                    return obj;
                }
              objFind(obj[key], item, value);             
                
            }else{ 
                if(obj[key] && obj[key].length >0){
                    if(Array.isArray(obj[key])){
                        for(var i=0;i<obj[key].length;i++){
                            var results = objFind(obj[key][i], item, value);
                            if(typeof results === "object" && obj[item]==value){
                                return obj;
                            }
                        }
                    }
                }
            }
        }
    }
    if(obj.length >0){
        for(var i=0;i<obj.length;i++){
            var results=objFind(obj[i], item, value);
            if(typeof results === "object"){
                return results;
            }
        }
    }
    else{
       var results=objFind(obj, item, value);
        if(typeof results === "object"){
            return obj;
        }
    }

}



function findObjectWithKey(json, key) {
  // Base case: If the input is not an object, return null
  if (typeof json !== 'object' || json === null) {
      return null;
  }
  
  // Check if the key exists in the current object
  if (json.hasOwnProperty(key) && Object.keys(json[key]).length > 0) {
    return json[key]
   
  }
  
  // Iterate through the object's properties recursively
  for (const prop in json) {
      const result = findObjectWithKey(json[prop], key);
      if (result !== null && Object.keys(result).length>0) {
        return result
          
      }
  }
  
  return null; // Key not found
}





function cleanObject(obj){
  
  const conf = JSON.parse(readFile('./settings').toString())

  //console.log(conf['IGNORE_TAG'])

  for (var key in conf['IGNORE_TAG']){  
    obj = removeKey(obj,conf['IGNORE_TAG'][key])    
  }

  return obj;
}



function removeKey(obj, key) {
  for(prop in obj) {
    if (prop === key)
      delete obj[prop];
    else if (typeof obj[prop] === 'object')
      removeKey(obj[prop],key);
  }

  return obj;
}


function isObjectEmpty(obj) {
    for (const prop in obj) {
      if (Object.hasOwn(obj, prop)) {
        return false;
      }
    }
  
    return true;
  }



  var updatedObjects = []
  var deletedObjects = []
  var addedObjects = []

  var updatedMetadataObjects = []
  var deletedMetadataObjects = []
  var addedMetadataObjects = []



  const oldFlowPath = "C:/Users/Admin/Downloads/1"
  const newFlowPath = "C:/Users/Admin/Downloads/3"

  

  var oldData = cleanObject(JSON.parse(readFile(oldFlowPath).toString()))  
  var newData = cleanObject(JSON.parse(readFile(newFlowPath).toString()))
   

  const oldIdentifierList = getidentifires(oldData.Actions)
  const newIdentifierList = getidentifires(newData.Actions)
  


  // Compare actions blocks to find which action objects are updated
  for (var objId in newIdentifierList){
    const oldObject = findObjectWithValue(oldData.Actions, "Identifier", newIdentifierList[objId])
    const newObject = findObjectWithValue(newData.Actions, "Identifier", newIdentifierList[objId])


   // console.log(oldData.Actions)
    //console.log(newIdentifierList[objId])

    const newObjectAdded = findObjectWithValue(oldData.Actions, "Identifier", newIdentifierList[objId])
    // console.log(newObjectAdded)

  //  console.log("=======================================")
    

    if (isObjectEmpty(newObjectAdded)){
        addedObjects.push(newObject)
    }

    const differences = deepDiff(oldObject, newObject);
    if (differences != null && ! isObjectEmpty(differences) ){
        updatedObjects.push(differences)
    }

  }





/// find deleted actions object
  for (var objId in oldIdentifierList){
    const oldObjectDeleted = findObjectWithValue(newData.Actions, "Identifier", oldIdentifierList[objId])
    const oldObject = findObjectWithValue(oldData.Actions, "Identifier", oldIdentifierList[objId])
    

    if (isObjectEmpty(oldObjectDeleted)){
        deletedObjects.push(oldObject)
    }

  }



  // Compare actions blocks to find which Metadata objects are updated
  for (var objId in newIdentifierList){
    const oldObject = findObjectWithKey(oldData.Metadata.ActionMetadata, newIdentifierList[objId])
    const newObject = findObjectWithKey(newData.Metadata.ActionMetadata, newIdentifierList[objId])

    console.log(JSON.stringify(oldObject,null,2))
    console.log(JSON.stringify(newObject,null,2))

    console.log("========================")
    

    const newObjectAdded = findObjectWithKey(oldData.Metadata.ActionMetadata, newIdentifierList[objId])

    if (isObjectEmpty(newObjectAdded)){
        addedMetadataObjects.push(newObject)
    }

    const differences = deepDiff(oldObject, newObject);
    if (differences != null && ! isObjectEmpty(differences) ){
        updatedMetadataObjects.push(differences)
    }

  }




 
/*
 
  console.log("=============  updated action blocks ================")
  console.log(JSON.stringify(updatedObjects,null,2))
  console.log("=============  updated metadata blocks ================")
  console.log(JSON.stringify(updatedMetadataObjects,null,2))



  console.log("=============  added action blocks ================")
  console.log(JSON.stringify(addedObjects,null,2))
  console.log("=============  added metadata blocks ================")
  console.log(JSON.stringify(addedMetadataObjects,null,2))



  console.log("=============  deleted blocks ================")
  console.log(JSON.stringify(deletedObjects,null,2))
  
  */